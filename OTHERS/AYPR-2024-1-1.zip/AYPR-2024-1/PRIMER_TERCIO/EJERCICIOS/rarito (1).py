"""PROGRAMA <Nombre del programa>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Número primo 
AUTOR(ES) : JSG
FECHA 14/02/24
"""


def main() -> None:
    # Descripción del programa
    """
    Este programa genera un patrón basado en la cantidad de grupos ingresados por el usuario.
    """

    # Declaración de variables
    """
    Variables:
    int, num: Cantidad de grupos ingresados por el usuario
    int, count: Contador para el bucle externo
    int, digit: Dígito que se imprime en el patrón
    int, rep: Contador para el bucle interno
    """

    num = -1
    while num < 0:
        num = int(input("Ingrese la cantidad de grupos que quiere: "))  # -> int
    count = 1  # -> int
    digit = 1  # -> int
    while count <= num:
        rep = 1  # -> int
        while rep <= count:
            print(digit, end=" ")
            rep += 1
        print("\n", end="")
        digit = digit * 2
        count += 1
    print("Adiós")

main()  # -> None


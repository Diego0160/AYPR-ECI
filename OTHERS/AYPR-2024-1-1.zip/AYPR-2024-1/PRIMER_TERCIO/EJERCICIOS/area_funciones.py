def pedir_lados() -> list[float]:
    # Descripción de la función
    """
    Esta función solicita dos lados de un rectángulo al usuario y los devuelve en una lista.
    """

    # Declaración de variables
    """
    Variables:
    float, lado1: Primer lado del rectángulo
    float, lado2: Segundo lado del rectángulo
    """

    lado1 = -1.0
    while lado1 < 0:
        lado1 = float(input("Ingrese su lado 1: "))  # -> float

    lado2 = -1.0
    while lado2 < 0:
        lado2 = float(input("Ingrese su lado 2: "))  # -> float
    return [lado1, lado2]

def h_area(lado1: float, lado2: float) -> float:
    # Descripción de la función
    """
    Esta función calcula el área de un rectángulo dado sus dos lados.
    """

    area = lado1 * lado2  # -> float
    return area

def h_perimetro(lado1: float, lado2: float) -> float:
    # Descripción de la función
    """
    Esta función calcula el perímetro de un rectángulo dado sus dos lados.
    """

    perimetro = 2 * lado1 + 2 * lado2  # -> float
    return perimetro

def mostrar_resultados(lado1: float, lado2: float, area: float, perimetro: float) -> None:
    # Descripción de la función
    """
    Esta función muestra los resultados del área y perímetro de un rectángulo.
    """

    print("\nSus lados son", lado1, "y", lado2, "\n", "\nSu área es:", area, "\nSu perímetro es:", perimetro)

def main() -> None:
    # Descripción del programa
    """
    Este programa calcula y muestra el área y perímetro de un rectángulo basado en sus lados ingresados por el usuario.
    """

    print("Hola\nEste programa te permite calcular el área y perímetro de un rectángulo")
   
    [lado1, lado2] = pedir_lados()  # -> list[float]

    area = h_area(lado1, lado2)  # -> float
    perimetro = h_perimetro(lado1, lado2)  # -> float
    mostrar_resultados(lado1, lado2, area, perimetro)

    print("Chao chao")

main()  # -> None


"""PROGRAMA <Calculodefinitivs>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Calcular la definitiva de un curso en la Escuela
AUTOR(ES) : Juan Esteban Sánchez García
FECHA 24/01/24
"""

def main() -> None:
    # Descripción del programa
    """
    Este programa calcula la nota definitiva de un semestre basado en las notas
    de tres tercios. Cada tercio tiene un peso específico en la nota final.
    """

    # Declaración de variables
    """
    Variables:
    float, notaT1: Nota del primer tercio
    float, notaT2: Nota del segundo tercio
    float, notaT3: Nota del tercer tercio
    float, definitiva: Nota definitiva del semestre
    """

    # Saludo inicial
    print("Bienvenido, este programa le ayudará a calcular su nota definitiva") 

    # Entrada de datos
    print("\t Datos de entrada")
    # Solicita la nota del primer tercio al usuario y la convierte a tipo float
    notaT1 = float(input("Ingrese la nota del primer tercio: "))  # -> float
    # Solicita la nota del segundo tercio al usuario y la convierte a tipo float
    notaT2 = float(input("Ingrese la nota del segundo tercio: "))  # -> float
    # Solicita la nota del tercer tercio al usuario y la convierte a tipo float
    notaT3 = float(input("Ingrese la nota del tercer tercio: "))  # -> float

    # Proceso de cálculo de la nota definitiva
    # La nota definitiva se calcula como un promedio ponderado de las tres notas
    # Primer tercio: 30%, Segundo tercio: 30%, Tercer tercio: 40%
    definitiva = ((notaT1 * 0.3) + (notaT2 * 0.3) + (notaT3 * 0.4))  # -> float

    # Mostrar datos
    print("\t Cálculo de la nota definitiva")
    # Muestra las notas ingresadas y la nota definitiva calculada
    print(
        "Las notas que usted ingresó son:",
        "\nPrimer tercio:", notaT1,
        "\nSegundo tercio:", notaT2,
        "\nTercer tercio:", notaT3,
        "\nSu nota definitiva del semestre es:", definitiva
    )

    # Despedida
    print("\nHa sido un placer servirte")
    print("\nAdiós")

# Llamada a la función principal
main()  # -> None


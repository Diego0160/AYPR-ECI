def pedir_cantidad() -> int:
    """
    Solicita al usuario una cantidad de números a evaluar, asegurándose de que sea un número positivo.
    
    Returns:
        int: La cantidad ingresada por el usuario.
    """
    n = -1
    while n < 0:
        n = int(input("Ingrese la cantidad que quiere evaluar: "))  # -> int
    return n

def pedir_numero() -> int:
    """
    Solicita al usuario un número mayor o igual que cero.
    
    Returns:
        int: El número ingresado por el usuario.
    """
    n = -1
    while n < 0:
        n = int(input("Ingrese un número mayor o igual que cero: "))  # -> int
    return n

def es_primo(numero: int) -> bool:
    """
    Verifica si un número es primo.
    
    Args:
        numero (int): El número a evaluar.
    
    Returns:
        bool: True si el número es primo, False en caso contrario.
    """
    if numero <= 1:
        return False
    div = 2
    while div <= numero // 2:
        if numero % div == 0:
            return False
        div += 1
    return True  # Si no se encontró un divisor, es primo.

def main() -> None:
    """
    Función principal que controla la lógica del programa.
    """
    cantidad = pedir_cantidad()  # -> int
    count_primo = 0  # -> int
    count = 1  # -> int

    while count <= cantidad:
        numero = pedir_numero()  # -> int
        if es_primo(numero):  # -> bool
            count_primo += 1
        count += 1

    print("Cantidad de números primos ingresados:", count_primo)  # -> None
    print("Adiós")  # -> None

main()  # -> None

num = int(input("Ingrese un número: "))  # -> int
i = 1  # -> int
while i <= num:
    print(str(i * 2) * i)
    i += 1

"""PROGRAMA <Nombre del programa>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Número primo
AUTOR(ES): Juan Esteban Sánchez García 
FECHA: 12/02/24
"""
def main() -> None:
    # Descripción del programa
    """
    Este programa determina si un número ingresado por el usuario es primo.
    """

    # Declaración de variables
    """
    Variables:
    int, num: Número ingresado por el usuario
    int, es_primo: Indicador de si el número es primo (1 = sí, 0 = no)
    int, div: Divisor para comprobar la primalidad
    """

    num = -1
    while num < 0:
        num = int(input("Ingrese un número positivo: "))  # -> int

    es_primo = 1  # -> int
    if num <= 1:
        es_primo = 0
    else:
        div = 2  # -> int
        while div <= num // 2:
            if num % div == 0:
                es_primo = 0
            div += 1
    if es_primo == 1:
        print("El número", num, "es primo")
    else:
        print("El número", num, "no es primo")
    print("\nAdiós")

main()  # -> None

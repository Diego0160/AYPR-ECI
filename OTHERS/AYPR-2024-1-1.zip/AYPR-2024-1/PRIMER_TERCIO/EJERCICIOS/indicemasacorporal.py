"""PROGRAMA <Nombre del programa>
================================================================

ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Calcular el indice de masa corporal del usuario
AUTOR(ES) : Juan Esteban Sánchez García
FECHA 24/01/24
"""

def main() -> None:
    # Descripción del programa
    """
    Este programa calcula el índice de masa corporal (IMC) de una persona
    basado en su altura y peso ingresados.
    """

    # Declaración de variables
    """
    Variables:
    float, altura: Altura de la persona en metros
    float, peso: Peso de la persona en kilogramos
    float, imc: Índice de masa corporal calculado
    """

    # Saludo inicial
    print("Bienvenido, este programa le ayudará a calcular su índice de masa corporal (IMC)")
    
    # Entrada de datos
    print("\tDatos de entrada")
    # Solicita la altura al usuario y la convierte a tipo float
    altura = float(input("Ingrese su altura en metros: "))  # -> float
    # Solicita el peso al usuario y lo convierte a tipo float
    peso = float(input("Ingrese su peso en kilogramos: "))  # -> float

    # Proceso de cálculo del IMC
    # Calcula el IMC como el peso dividido por el cuadrado de la altura
    imc = peso / (altura ** 2)  # -> float

    # Mostrar datos
    print("\tCálculo IMC")
    # Muestra la altura, el peso y el IMC calculado
    print("La altura ingresada es:", altura, "\nEl peso ingresado es:", peso, "\nSu índice de masa corporal es:", imc)
    
# Llamada a la función principal
main()  # -> None


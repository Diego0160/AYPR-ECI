"""PROGRAMA <Nombre del programa>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Aprender bucle while
AUTOR(ES): Juan Esteban Sánchez García 
FECHA: 05/02/24
"""
def main() -> None:
    # Descripción del programa
    """
    Este programa realiza varias operaciones, incluyendo la suma de divisores de un número positivo y el cálculo del factorial.
    """

    # Declaración de variables
    """
    Variables:
    int, numero: Número ingresado por el usuario
    int, suma: Suma de los divisores de numero
    int, div: Divisor para encontrar los divisores de numero
    """

    numero = -1
    while numero <= 0:
        numero = int(input("Ingrese un número positivo: "))  # -> int

    suma = 1 + numero  # -> int
    div = 2  # -> int
    print("El número 1 es divisor")
    while div <= numero // 2:
        if numero % div == 0:
            print("El número", div, "es divisor")
            suma += div
        div += 1
    print("La suma de sus divisores es:", suma)
    print("\nAdiós")

main()  # -> None


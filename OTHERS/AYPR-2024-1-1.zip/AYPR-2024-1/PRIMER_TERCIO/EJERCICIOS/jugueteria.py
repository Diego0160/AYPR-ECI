"""PROGRAMA <jugueteria>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Calcúlar el precio del paquete de una jugueteria
AUTOR(ES) : Juan Esteban Sánchez García
FECHA 24/01/24
"""

def main() -> None:
    # Descripción del programa
    """
    Este programa calcula el peso total de un envío basado en la cantidad de 
    payasos y muñecas. Cada payaso pesa 112 gramos y cada muñeca pesa 75 gramos.
    """

    # Declaración de variables
    """
    Variables:
    int, cantidad_payaso: Cantidad de payasos en el envío
    int, cantidad_muñeca: Cantidad de muñecas en el envío
    int, peso_total: Peso total del envío en gramos
    """

    # Saludo inicial
    print("Bienvenido, este programa le ayudará a calcular el peso de su envío") 

    # Entrada de datos
    print("\tDATOS DE ENTRADA")
    print("Tenga en cuenta que el payaso tiene un peso de 112g y la muñeca de 75g")

    # Solicita la cantidad de payasos al usuario y la convierte a tipo int
    cantidad_payaso = int(input("Ingrese la cantidad de payasos que requiere: "))  # -> int
    # Solicita la cantidad de muñecas al usuario y la convierte a tipo int
    cantidad_muñeca = int(input("Ingrese la cantidad de muñecas que requiere: "))  # -> int

    # Proceso de cálculo del peso total
    # Calcula el peso total en gramos como la suma del peso de los payasos y muñecas
    peso_total = (cantidad_payaso * 112) + (cantidad_muñeca * 75)  # -> int

    # Mostrar datos
    print("\tPESO TOTAL")
    # Muestra la cantidad de payasos y muñecas, así como el peso total calculado
    print(
        "Usted pidió", cantidad_payaso, "Payasos", "y", cantidad_muñeca, "Muñecas",
        "\nEstos tienen un peso de:",
        "\nPayasos:", (cantidad_payaso * 112), "gramos",
        "\nMuñecas:", (cantidad_muñeca * 75), "gramos"
    )

    print("Su peso total del envío es:", peso_total, "gramos")

    # Despedida
    print("\nHa sido un placer servirte")
    print("\nAdiós")

# Llamada a la función principal
main()  # -> None


"""PROGRAMA <Nombre del programa>
================================================================

ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Binomio de newton
AUTOR(ES) : Juan Esteban Sánchez García 
FECHA 19/02/24
"""
def main() -> None:
    # Descripción del programa
    """
    Este programa calcula el coeficiente binomial de dos números positivos ingresados por el usuario.
    """

    # Declaración de variables
    """
    Variables:
    int, n: Primer número ingresado por el usuario
    int, k: Segundo número ingresado por el usuario
    int, factorialN: Factorial de n
    int, factorialK: Factorial de k
    int, factorialR: Factorial de (n - k)
    int, countFact: Contador para calcular factoriales
    float, resultado: Resultado del coeficiente binomial
    """

    n = -1
    k = -1
    while n <= 0:
        n = int(input("Ingrese el primer número (n): "))  # -> int
    while k <= 0 or k > n:
        k = int(input("Ingrese el segundo número (k): "))  # -> int
    # Factorial de n
    factorialN = 1  # -> int
    countFact = 1  # -> int
    while countFact <= n:
        factorialN = factorialN * countFact
        countFact += 1
    print("El factorial de", n, "es", factorialN)
    # Factorial de k
    factorialK = 1  # -> int
    countFact = 1  # -> int
    while countFact <= k:
        factorialK = factorialK * countFact
        countFact += 1
    print("El factorial de", k, "es", factorialK)
    # Factorial de la resta
    factorialR = 1  # -> int
    countFact = 1  # -> int
    while countFact <= (n - k):
        factorialR = factorialR * countFact
        countFact += 1
    print("El factorial de", (n - k), "es", factorialR)
    
    # Fórmula
    resultado = factorialN / (factorialK * factorialR)  # -> float
    print("El resultado de su coeficiente binomial es:", int(resultado))
    
    print("Adiós")

main()  # -> None


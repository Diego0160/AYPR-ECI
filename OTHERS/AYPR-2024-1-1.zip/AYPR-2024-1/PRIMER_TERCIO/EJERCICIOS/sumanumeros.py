"""PROGRAMA <Nombre del programa>
================================================================

ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Sumar dos números enteros
AUTOR(ES) : Juan Esteban Sánchez
FECHA 24/01/24
"""
def main() -> None:
    # Descripción del programa
    """
    Este programa ayuda a sumar dos números enteros ingresados por el usuario.
    """

    # Declaración de variables
    """
    Variables:
    int, num1: Primer número entero a sumar
    int, num2: Segundo número entero a sumar
    int, suma: Resultado de la suma de num1 y num2
    """

    # Saludo inicial
    print("Bienvenidos, este es un programa de ayuda a sumar dos números enteros")
    
    # Entrada de datos
    print("\tDatos de entrada")
    # Solicita el primer número al usuario y lo convierte a tipo int
    num1 = int(input("Ingrese el primer número para sumar: "))  # -> int
    # Solicita el segundo número al usuario y lo convierte a tipo int
    num2 = int(input("Ingrese el segundo número para sumar: "))  # -> int

    # Proceso de suma
    suma = num1 + num2  # -> int

    # Mostrar datos
    print("\nEl resultado de sumar", num1, "y", num2, "es:", suma, "\n")
    
    # Despedida
    print("\nHa sido un placer servirte")
    print("Adiós")

# Llamada a la función principal
main()  # -> None


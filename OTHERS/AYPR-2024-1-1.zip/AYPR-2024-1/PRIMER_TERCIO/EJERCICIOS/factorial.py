"""PROGRAMA <Nombre del programa>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Factorial
AUTOR(ES): Juan Esteban Sánchez García 
FECHA: 12/02/24
"""
def main() -> None:
    # Descripción del programa
    """
    Este programa calcula el factorial de un número positivo ingresado por el usuario.
    """

    # Declaración de variables
    """
    Variables:
    float, n: Número positivo ingresado por el usuario
    int, factorial: Resultado del cálculo del factorial
    int, count: Contador para el bucle
    """

    n = -1.0
    while n < 0:
        n = float(input("Ingrese un número positivo: "))  # -> float
    factorial = 1  # -> int
    count = 1  # -> int
    while count <= n:
        factorial = factorial * count
        count += 1
    print("El factorial de", n, "es", factorial)
    print("\nAdiós")

main()  # -> None


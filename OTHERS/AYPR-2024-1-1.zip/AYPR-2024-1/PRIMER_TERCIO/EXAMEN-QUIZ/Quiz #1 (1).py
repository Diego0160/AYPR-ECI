"""PROGRAMA <Quiz #1 >
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Desarrollar los puntos del quiz #1
AUTOR(ES) : Francisco Gomez,Juan Esteban Sánchez
FECHA: 07/02/24
"""
def main() -> None:
    # Descripción del programa
    """
    Este programa permite al usuario ingresar su voto y realiza operaciones basadas en el día de la semana.
    """

    print("Bienvenidos al desarrollo del quiz #1")

    # Desarrollo punto 1
    """
    Variables:
    str, voto: Voto ingresado por el usuario
    """
    print("Vote 1 para rojo\nVote 2 para verde\nVote 3 para azul")
    voto = str(input("Ingrese su voto: "))  # -> str
     
    if voto == "1":
        print("Usted ha elegido el partido rojo")
    elif voto == "2":
        print("Usted ha elegido el partido verde")
    elif voto == "3":
        print("Usted ha elegido el partido azul")
    else:
        print("Opción incorrecta")

    # Desarrollo punto 2
    """
    Variables:
    str, dia_semana: Día de la semana ingresado por el usuario
    int, numero_dia: Número del día ingresado por el usuario
    int, numero_mes: Número del mes ingresado por el usuario
    """
    dia_semana = str(input("Seleccione el día de la semana: "))  # -> str
    numero_dia = int(input("Seleccione el número de día: "))  # -> int
    numero_mes = int(input("Seleccione el número del mes: "))  # -> int
    
    if dia_semana.lower() in ["lunes", "martes", "miércoles"]:
        examen = str(input("Diga si hubo examen o no: "))  # -> str
        if examen.lower() == "si":
            aprobados = int(input("Ingrese cuántos aprobaron: "))  # -> int
            desaprobados = int(input("Ingrese cuántos desaprobaron: "))  # -> int
            numero_total = aprobados + desaprobados  # -> int
            porcentaje_aprobados = (aprobados * 100) / numero_total  # -> float
            print("El porcentaje de aprobados es", porcentaje_aprobados)
        else:
            print("No hubo examen")
            
    elif dia_semana.lower() == "jueves":
        asistencia = float(input("Ingrese el porcentaje de asistencia %: "))  # -> float
        if 50 <= asistencia <= 100:
            print("Asistió la mayoría")
        else:
            print("No asistió la mayoría")
            
    elif dia_semana.lower() == "viernes" and numero_dia == 1 and numero_mes in [1, 7]:
        print("Comienzo de nuevo ciclo")
        valor_por_alumno = float(input("Ingrese el arancel por alumno: "))  # -> float
        cantidad_alumnos = int(input("Ingrese cuántos alumnos ingresaron: "))  # -> int
        arancel = cantidad_alumnos * valor_por_alumno  # -> float
        print("El ingreso total es $", arancel)
           
    print("Fue un placer servirle")

main()  # -> None


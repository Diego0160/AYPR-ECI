"""PROGRAMA <Parcial #1 >
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Desarrollar los puntos del Parcial #1
AUTOR(ES) : Juan Esteban Sànchez
FECHA: 20 de febrero
"""
def main() -> None:
    # Descripción del programa
    """
    Este programa realiza varias operaciones, incluyendo cálculos de mesada donada y la generación de un patrón.
    """

    # Desarrollo punto 1
    """
    Variables:
    str, nombre: Nombre del usuario
    int, aporte: Indicador de si el usuario desea aportar (1 = sí, 0 = no)
    float, valor_mesada_mes: Valor de la mesada mensual del usuario
    float, porcentaje: Porcentaje de la mesada que el usuario donará
    float, total_donado: Total donado por el usuario
    """
    print("\t Para sí, oprima 1, para no oprima 0")
    nombre = ""  # -> str
    aporte = 0  # -> int
    while aporte == 0:
        nombre = input("Ingrese su nombre: ")  # -> str
        aporte = int(input("Desea aportar (1 para sí, 0 para no): "))  # -> int
        if aporte == 1:
            valor_mesada_mes = float(input("Ingrese su mesada por mes: "))  # -> float
            porcentaje = float(input("Ingrese el porcentaje que va a donar: "))  # -> float
            total_donado = (valor_mesada_mes * porcentaje) / 100 * 4  # -> float
            print(nombre, "tu total donado es", total_donado)
    
    # Desarrollo punto 2
    """
    Variables:
    int, n: Número ingresado por el usuario
    int, count: Contador para el bucle externo
    int, digit: Dígito que se imprime en el patrón
    int, rep: Contador para el bucle interno
    """
    num = int(input("Enter a number: "))
    n = num
    while n >= 1:
        rep = num
    while rep >= n:
        print(rep, end="")
        rep -= 1
    print(" ", end="")
    n -= 1

    print("Fue un placer servirle")

main()  # -> None



# AYPR-Pimienta

Hola, si estas leyendo esto es porque tal vez te pase los documentos de AYPR 2024-1, no creo que cambie mucho en el momento que estes leyendo esto, en la carpeta encontraras todo organizado por tercios como a la profesora Marta Pimienta le gusta trabajar, la verdad solo es practicar y sera facil pasar :).

Buena suerte futuro programad@r 


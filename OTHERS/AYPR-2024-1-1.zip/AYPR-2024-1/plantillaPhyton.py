"""PROGRAMA <Nombre del programa>
================================================================

ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : ??
AUTOR(ES) : ???
FECHA ???
"""


def main():

    print("Adiós")

    
main()

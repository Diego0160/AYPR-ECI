MAX = 100

def crear_inicializar():
    # Inicializo el vector
    vector = [0 for pos in range (0, MAX)]
    return vector 

def pide_numero():
    n = -1
    while n < 0:
        n = int(input("Ingrese su número que va a convertir de decimal a binario: "))
    return n

def conversor_decimal_a_binario(n, vector):
    # Convierte el número decimal a binario y lo almacena en un vector
    pos = 0
    while n > 0:
        vector[pos] = n % 2
        n = n // 2
        pos += 1
    return vector

def mostrar_resultados(vector):
    # Mostrar vector en orden normal
    print("En orden normal: [", end="")
    pos = MAX - 1
    while pos >= 0 and vector[pos] == 0:  # Ignora los ceros iniciales
        pos -= 1
    for i in range(pos, -1, -1):  # Imprime desde el primer 1 hasta el final
        print(vector[i], end=" ")
    print("]")

    # Mostrar vector en orden inverso
    print("En orden inverso: [", end="")
    for i in range(0, pos+1):  # Imprime desde el inicio hasta el primer 1
        print(vector[i], end=" ")
    print("]")

def main():
    vector = crear_inicializar()
    numero = pide_numero()
    vector = conversor_decimal_a_binario(numero, vector)
    mostrar_resultados(vector)

main()

def main():
    vector = crear_inicializar()
    numero = pide_numero()
    vector = conversor_decimal_a_binario(numero, vector)
    mostrar_resultados(vector)

main()








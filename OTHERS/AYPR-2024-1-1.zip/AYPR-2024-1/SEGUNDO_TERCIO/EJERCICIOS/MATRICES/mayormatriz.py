MAXFIL = 20  # Variable global de tipo entero (int)
MAXCOL = 20  # Variable global de tipo entero (int)

def crear_inicializador():
    matrix = [[0 for nc in range(MAXCOL)] for nf in range(MAXFIL)]  # Lista de listas (matriz) de enteros (int)
    return matrix

def pedir_tamaño(mensaje):
    tam = -1  # Variable de tipo entero (int)
    if mensaje == "filas":
        while tam <= 0 or tam >= MAXFIL:
            print("Enter the number of rows: ")
            tam = int(input())  # Conversión de entrada (str) a entero (int)
    else:
        while tam <= 0 or tam >= MAXCOL:
            print("Enter the number of columns: ")
            tam = int(input())  # Conversión de entrada (str) a entero (int)
    return tam

def llenar_matriz(matrix, filas, columnas):
    for f in range(0, filas):
        for c in range(0, columnas):
            matrix[f][c] = int(input("Enter the element of the matrix: "))  # Conversión de entrada (str) a entero (int)
    return matrix

def encontrar_maximo(matrix, filas, columnas):
    max_val = -1  # Variable de tipo entero (int)
    for f in range(0, filas):
        for c in range(0, columnas):
            if matrix[f][c] > max_val:
                max_val = matrix[f][c]
    return max_val

def mostrar_matriz(matrix, filas, columnas):
    for f in range(0, filas):
        for c in range(0, columnas):
            print('(', matrix[f][c], ')', end = " ")
        print("\n")

def mostrar_resultados(matrix, matrix2, filas, columnas):
    print("Datos de la matriz")
    mostrar_matriz(matrix, filas, columnas)
    print("The highest value on the first matrix is: ", encontrar_maximo(matrix, filas, columnas))
    mostrar_matriz(matrix2, filas, columnas)
    print("The highest value on the second matrix is: ", encontrar_maximo(matrix2, filas, columnas))

def main():
    print("Welcome")
    filas = pedir_tamaño("filas")  # Variable de tipo entero (int)
    columnas = pedir_tamaño("columnas")  # Variable de tipo entero (int)

    print("Enter the elements of the first matrix: ")
    matrix = crear_inicializador()  # Variable de tipo lista de listas (matriz)
    matrix = llenar_matriz(matrix, filas, columnas)

    print("Enter the elements of the second matrix: ")
    matrix2 = crear_inicializador()  # Variable de tipo lista de listas (matriz)
    matrix2 = llenar_matriz(matrix2, filas, columnas)

    mostrar_resultados(matrix, matrix2, filas, columnas)

    print("Cya!")

main()

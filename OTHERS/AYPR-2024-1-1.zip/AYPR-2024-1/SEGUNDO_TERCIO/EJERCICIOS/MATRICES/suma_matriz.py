import random 

MAXROW: int = 20
MAXCOL: int = 20

def crear_inicializador() -> list[list[int]]:
    matrix: list[list[int]] = [[0 for nc in range(MAXCOL)] for nf in range(MAXROW)]
    return matrix

def pedir_tamaño(mensaje: str) -> int:
    tam: int = -1
    if mensaje == "filas":
        while tam <= 0 or tam >= MAXROW:
            print("Enter the number of rows: ")
            tam = int(input())
    else:
        while tam <= 0 or tam >= MAXCOL:
            print("Enter the number of columns: ")
            tam = int(input())
    return tam

def llenar_matriz(matrix: list[list[int]], filas: int, columnas: int) -> list[list[int]]:
    for f in range(0, filas):
        for c in range(0, columnas):
            matrix[f][c] = random.randrange(-50, 100)
    return matrix

def suma_diagonal_principal(matrix: list[list[int]], filas: int, columnas: int) -> int:
    suma: int = 0
    for f in range(filas):
        suma += matrix[f][f]
    return suma

def suma_arriba(matrix: list[list[int]], filas: int, columnas: int) -> int:
    suma: int = 0
    for f in range(filas):
        for c in range(f+1, columnas):
            suma += matrix[f][c]
    return suma

def suma_abajo(matrix: list[list[int]], filas: int, columnas: int) -> int:
    suma: int = 0
    for f in range(1, filas):
        for c in range(f):
            suma += matrix[f][c]
    return suma

def mostrar_matriz(matrix: list[list[int]], filas: int, columnas: int) -> None:
    for f in range(0, filas):
        for c in range(0, columnas):
            print('(', matrix[f][c], ')', end = " ")
        print("\n")

def mostrar_resultados(matrix: list[list[int]], filas: int, columnas: int) -> None:
    print("Datos de la matriz")
    mostrar_matriz(matrix, filas, columnas)
    print("Suma de la diagonal principal: ", suma_diagonal_principal(matrix, filas, columnas))
    print("Suma de los elementos por encima de la diagonal principal: ", suma_arriba(matrix, filas, columnas))
    print("Suma de los elementos por debajo de la diagonal principal: ", suma_abajo(matrix, filas, columnas))

def main() -> None:
    print("Saludo")
    matrix: list[list[int]] = crear_inicializador()
    filas: int = pedir_tamaño("filas")
    columnas: int = pedir_tamaño("columnas")
    llenar_matriz(matrix, filas, columnas)
    mostrar_resultados(matrix, filas, columnas)

main()


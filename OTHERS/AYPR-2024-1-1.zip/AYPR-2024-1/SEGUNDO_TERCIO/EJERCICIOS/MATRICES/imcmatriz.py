import random  # Importación del módulo random
MAXROW = 20  # Variable global de tipo entero (int)
MAXCOL = 20  # Variable global de tipo entero (int)

def crear_inicializador():
    matrix = [[0 for nc in range(MAXCOL)] for nf in range(MAXROW)]  # Lista de listas (matriz) de enteros (int)
    return matrix

def pedir_tamaño(mensaje):
    tam = -1  # Variable de tipo entero (int)
    if mensaje == "filas":
        while tam <= 0 or tam >= MAXROW:
            print("Enter the number of rows: ")
            tam = int(input())  # Conversión de entrada (str) a entero (int)
    else:
        while tam <= 0 or tam >= MAXCOL:
            print("Enter the number of columns: ")
            tam = int(input())  # Conversión de entrada (str) a entero (int)
    return tam

def llenar_matriz(matrix, filas, columnas):
    for f in range(0, filas):
        for c in range(0, columnas):
            matrix[f][c] = random.randrange(10, 50)  # Número aleatorio entre 10 y 49 (int)
    return matrix

def clasificar_imc(matrix, filas, columnas):
    bajo_peso = 0  # Variable de tipo entero (int)
    peso_normal = 0  # Variable de tipo entero (int)
    sobrepeso = 0  # Variable de tipo entero (int)
    obesidad = 0  # Variable de tipo entero (int)
    for f in range(0, filas):
        for c in range(0, columnas):
            imc = matrix[f][c]  # Variable de tipo entero (int)
            if imc < 18.5:
                bajo_peso += 1
            elif 18.5 <= imc < 25.0:
                peso_normal += 1
            elif 25.0 <= imc < 30.0:
                sobrepeso += 1
            else:
                obesidad += 1
    print("Bajo de peso: ", bajo_peso)
    print("Peso normal o adecuado: ", peso_normal)
    print("Sobrepeso: ", sobrepeso)
    print("Obesidad: ", obesidad)

def mostrar_matriz(matrix, filas, columnas):
    for f in range(0, filas):
        for c in range(0, columnas):
            print('(', matrix[f][c], ')', end = " ")
        print("\n")

def mostrar_resultados(matrix, filas, columnas):
    print("Datos de la matriz")
    mostrar_matriz(matrix, filas, columnas)

def main():
    print("Welcome")
    filas = pedir_tamaño("filas")  # Variable de tipo entero (int)
    columnas = pedir_tamaño("columnas")  # Variable de tipo entero (int)

    matrix = crear_inicializador()  # Lista de listas (matriz)
    matrix = llenar_matriz(matrix, filas, columnas)

    mostrar_resultados(matrix, filas, columnas)
    clasificar_imc(matrix, filas, columnas)

    print("Cya!")

main()


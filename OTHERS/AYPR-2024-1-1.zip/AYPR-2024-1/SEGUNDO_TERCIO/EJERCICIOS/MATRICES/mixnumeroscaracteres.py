"""PROGRAMA <Sumatoria de elementos del vector>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Bucles for
AUTOR(ES) : Juan Esteban Sánchez
FECHA: 6 de marzo
"""
"""PROGRAMA <Sumatoria de elementos del vector>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Bucles for
AUTOR(ES) : Juan Esteban Sánchez
FECHA: 6 de marzo
"""
MAX = 20  # Variable global de tipo entero (int)

def crear_inicializar():
    vector = ["*" for pos in range(MAX)]  # Lista de cadenas (str)
    return vector

def pide_tamaño():
    num = -1  # Variable de tipo entero (int)
    while num <= 0 or num > MAX:
        print("Recuerde que debe ingresar un número entre 1 y", MAX)
        num = int(input("\nIngrese número: "))  # Conversión de entrada (str) a entero (int)
    return num    

def llenar_vector_numeros(vector, tam):
    print("Datos del vector")

    for pos in range(tam):
        print("\tRecuerde que tiene que ingresar números")
        numero = int(input("\nIngrese el numero para el vector: "))  # Conversión de entrada (str) a entero (int)
        vector[pos] = numero - 1  # Operación aritmética con enteros (int)

def llenar_vector_con_letras(vector, tam):
    print("Datos del vector")

    for pos in range(tam):
        print("\tRecuerde que tiene que ingresar caracteres")
        caracter = str(input("\nIngrese el caracter para el vector: "))  # Conversión de entrada (str) a cadena (str)
        vector[pos] = caracter

def mostrar_resultados(vector_numeros, vector_letras, tam):
    print("\tDatos del vector")
    print("\t", end="")

    for i in range(tam):
        print(vector_letras[vector_numeros[i] - 1], end="")  # Operación con índices de listas

    print()

def main():
    print("\nMe da los caracteres de un vector.")

    vector_numeros = crear_inicializar()  # Lista de enteros (int)
    vector_letras = crear_inicializar()  # Lista de cadenas (str)

    tam = pide_tamaño()  # Variable de tipo entero (int)

    llenar_vector_numeros(vector_numeros, tam)
    llenar_vector_con_letras(vector_letras, tam)

    print("\nResultado:")
    mostrar_resultados(vector_numeros, vector_letras, tam)
    print("\nFue un placer servirle")

main()

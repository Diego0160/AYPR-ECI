MAXFIL: int = 20
MAXCOL: int = 20

def crear_inicializador() -> list[list[int]]:
    matrix: list[list[int]] = [[0 for nc in range(MAXCOL)] for nf in range(MAXFIL)]
    return matrix

def pedir_tamaño(mensaje: str) -> int:
    tam: int = -1
    if mensaje == "filas":
        while tam <= 0 or tam >= MAXFIL:
            print("Digite la cantidad de filas: ")
            tam = int(input())
    else:
        while tam <= 0 or tam >= MAXCOL:
            print("Digite la cantidad de columnas: ")
            tam = int(input())
    return tam

def llenar_matriz(matrix: list[list[int]], filas: int, columnas: int) -> None:
    for f in range(0, filas):
        for c in range(0, columnas):
            matrix[f][c] = int(input("Digite el elemento de la matriz: "))
    
def mostrar_matriz(matrix: list[list[int]], filas: int, columnas: int) -> None:
    for f in range(0, filas):
        for c in range(0, columnas):
            print(matrix[f][c], end = " ")
        print("\n")

def sumar(matrix: list[list[int]], filas: int, columnas: int) -> int:
    suma: int = 0
    for f in range(0, filas):
        for c in range(0, columnas):
            suma += matrix[f][c]
    return suma 

def mostrar_resultados(matrix: list[list[int]], filas: int, columnas: int, suma: int) -> None:
    print("Datos de la matriz")
    mostrar_matriz(matrix, filas, columnas)
    print("La suma de los elementos de la matriz es", suma)

def main() -> None:
    print("Saludo")
    matrix: list[list[int]] = crear_inicializador()
    filas: int = pedir_tamaño("filas")
    columnas: int = pedir_tamaño("columnas")
    llenar_matriz(matrix, filas, columnas)
    suma: int = sumar(matrix, filas, columnas)
    mostrar_resultados(matrix, filas, columnas, suma)

main()


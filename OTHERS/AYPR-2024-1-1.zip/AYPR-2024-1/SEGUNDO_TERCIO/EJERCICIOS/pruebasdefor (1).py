def main():

#Prueba 1 de for

#En este for la i comienza en 0 y termina en 10 -1  . La palabra hola se imprime 10 veces
    for i in range(10):
      
        print("Hola ", end="")
    print(i,"Este es i")
    print()
    print("Final")

#En este for la j comienza en 0 y termina en canti - 1 . La palabra OtrasHolas se imprime canti veces
    canti = int(input("¿Cuántas veces quiere que le salude? "))
    for j in range(canti):
        
        print("OtrasHolas ", end="")
    print(j,"Este es j")
    print()
    print("Adiós")

#En este for la i comienza en 1 y termina en 9 - 1 . La palabra OtrasHolas se imprime 8 veces    
    for k in range(1,9):
        
        print("OtrasHolas ", end="")
        print(k,"Este es k")
    print()
    print(k,"Este es k")
    print("Adiós")


#En este for la i comienza en 1 y termina en 9 - 1 . Y va de 2 en dos. La palabra OtrasHolas se imprime 4 veces

    for p in range(1,9, 2):
        
        print("OtrasHolas ", end="")
        print(p,"Este es p")
    print()
    print(p,"Este es p")
    print("Adiós")
main()

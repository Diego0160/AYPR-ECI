"""PROGRAMA <Sumatoria de elementos del vector>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Hacer un programa modular para sumar los elementos de un vector
AUTOR(ES) : Martha Pimienta
FECHA: 2 de marzo
"""
MAX = 50  # Variable global de tipo entero (int)

def crear_inicializar():
    vector = [0 for pos in range(MAX)]  # Lista de enteros (int)
    return vector

def pide_tamaño():
    num = -1  # Variable de tipo entero (int)
    while num <= 0 or num > MAX:
        print("Recuerde que debe ingresar un número entre 1 y", MAX)
        num = int(input("\nIngrese número: "))  # Conversión de entrada (str) a entero (int)
    return num    

def potencia_datos(vector, tam, numero):
    for pos in range(tam):
        vector[pos] = numero ** (pos + 1)  # Operación de potenciación con enteros (int)

def mostrar_resultados(vector, tam):
    print("\tDatos del vector")
    print("\t", end="")

    print("[", end="")
    for pos in range(tam):
        print(vector[pos], end=" ")  # Iteración sobre enteros (int)
    print("]", end="")

def main():
    print("\nMe da la potencia de un vector.")

    vector = crear_inicializar()  # Lista de enteros (int)

    tam = pide_tamaño()  # Variable de tipo entero (int)

    numero = int(input("\nIngrese el número para calcular potencias: "))  # Conversión de entrada (str) a entero (int)

    potencia_datos(vector, tam, numero)

    mostrar_resultados(vector, tam)
    print("\nFue un placer servirle")

main()


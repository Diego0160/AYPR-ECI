"""PROGRAMA <Nombre del programa>
================================================================

ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : ??
AUTOR(ES) : ???
FECHA ???
"""

MAX: int = 20  # Máximo tamaño del vector

def crear_inicializar(tam: int) -> list[str]:
    vector: list[str] = ['' for _ in range(tam)]
    return vector

def pide_tamaño() -> int:
    num: int = -1
    while num <= 0 or num > MAX:
        print("Recuerde que debe ingresar un número entre 1 y", MAX)
        num = int(input("\nIngrese número: "))
    return num

def pide_letras(tam: int) -> str:
    letras: str = ""
    for i in range(tam):
        letra: str = input(f"Ingrese letra {i + 1}: ")
        letras += letra
    return letras

def llenar_vector(vector: list[int], tam: int) -> None:
    print("Datos del vector")
    for pos in range(tam):
        numero: int = int(input("\nIngrese elemento del vector: "))
        vector[pos] = numero

def generar_palabra(vector_num: list[int], vector_letras: str) -> str:
    palabra: str = ""
    for num in vector_num:
        palabra += vector_letras[num - 1]
    return palabra

def mostrar_resultados(vector: list[int], tam: int, palabra: str) -> None:
    print("\nDatos del vector:")
    print("[", end="")
    for pos in range(tam):
        print(vector[pos], end=" ")
    print("]")

    print("\nPalabra formada:", palabra)

def main() -> None:
    print("\nFormación de palabra a partir de vectores.")

    tam: int = pide_tamaño()
    vector: list[int] = crear_inicializar(tam)
    llenar_vector(vector, tam)
    letras: str = pide_letras(tam)
    palabra: str = generar_palabra(vector, letras)
    mostrar_resultados(vector, tam, palabra)

    print("\nFue un placer servirle.")

main()


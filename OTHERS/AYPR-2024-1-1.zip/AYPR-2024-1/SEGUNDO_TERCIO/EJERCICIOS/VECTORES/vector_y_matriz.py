import random 

MAXROW: int = 20
MAXCOL: int = 20

def crear_inicializador() -> list[list[int]]:
    matrix: list[list[int]] = [[0 for nc in range(MAXCOL)] for nf in range(MAXROW)]
    return matrix

def pedir_tamaño(mensaje: str) -> int:
    tam: int = -1
    if mensaje == "filas":
        while tam <= 0 or tam >= MAXROW:
            print("Enter the number of rows: ")
            tam = int(input())
    else:
        while tam <= 0 or tam >= MAXCOL:
            print("Enter the number of columns: ")
            tam = int(input())
    return tam

def llenar_matriz(matrix: list[list[int]], filas: int, columnas: int) -> list[list[int]]:
    for f in range(0, filas):
        for c in range(0, columnas):
            matrix[f][c] = random.randrange(-50, 100)
    return matrix

def suma_filas(matrix: list[list[int]], filas: int, columnas: int) -> list[int]:
    vector_filas: list[int] = [0 for k in range(filas)]
    for f in range(0, filas):
        for c in range(0, columnas):
            vector_filas[f] += matrix[f][c]
    return vector_filas

def suma_columnas(matrix: list[list[int]], filas: int, columnas: int) -> list[int]:
    vector_columnas: list[int] = [0 for i in range(columnas)]
    for c in range(0, columnas):
        for f in range(0, filas):
            vector_columnas[c] += matrix[f][c]
    return vector_columnas
            
def mostrar_matriz(matrix: list[list[int]], filas: int, columnas: int) -> None:
    for f in range(0, filas):
        for c in range(0, columnas):
            print('(', matrix[f][c], ')', end = " ")
        print("\n")
        
def mostrar_resultados(matrix: list[list[int]], filas: int, columnas: int, vector_filas: list[int], vector_columnas: list[int]) -> None:
    print("Datos de la matriz")
    mostrar_matriz(matrix, filas, columnas)
    print("La suma de los elementos de cada fila es", vector_filas)
    print("La suma de los elementos de cada columna es", vector_columnas)

def main() -> None:
    print("Saludo")
    matrix: list[list[int]] = crear_inicializador()
    filas: int = pedir_tamaño("filas")
    columnas: int = pedir_tamaño("columnas")
    llenar_matriz(matrix, filas, columnas)
    vector_filas: list[int] = suma_filas(matrix, filas, columnas)
    vector_columnas: list[int] = suma_columnas(matrix, filas, columnas)
    mostrar_resultados(matrix, filas, columnas, vector_filas, vector_columnas)

main()



﻿"""PROGRAMA <Sumatoria de elementos del vector>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Hacer un programa modular para sumar los elementos de un vector
AUTOR(ES) : Martha Pimienta
FECHA: 2 de marzo
"""
MAX = 200  # Máximo tamaño del vector

def crear_inicializar() -> list:
    vector = [0 for _ in range(MAX)]
    return vector

def pide_tamaño() -> int:
    num = -1
    while num <= 0 or num > MAX:
        print("Recuerde que debe ingresar un número entre 1 y", MAX)
        num = int(input("\nIngrese número: "))
    return num

def llenar_vector(vector: list, tam: int) -> None:
    print("Datos del vector")
    for pos in range(tam):
        numero = int(input("\nIngrese elemento del vector: "))
        vector[pos] = numero

def suma_datos(vector: list, tam: int) -> int:
    suma = 0
    for pos in range(tam):
        suma += vector[pos]
    return suma

def mostrar_resultados(vector: list, tam: int, suma: int) -> None:
    print("\tDatos del vector")
    print("\t[", end="")
    for pos in range(tam):
        print(vector[pos], end=" ")
    print("]", end="")
    print("\nLa suma es", suma)

def main() -> None:
    print("\nSuma el contenido de un vector.")
    vector = crear_inicializar()
    tam = pide_tamaño()
    llenar_vector(vector, tam)
    suma = suma_datos(vector, tam)
    mostrar_resultados(vector, tam, suma)
    print("\nFue un placer servirle")

main()


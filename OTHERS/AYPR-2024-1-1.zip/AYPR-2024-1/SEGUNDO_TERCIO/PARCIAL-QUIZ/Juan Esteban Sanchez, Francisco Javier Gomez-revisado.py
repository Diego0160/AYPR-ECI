"""PROGRAMA <Quiz Segundo tercio>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Hacer un programa modular para realizar los dos puntos del quiz
AUTOR(ES) : Juan Esteban Sanchez, Francisco Javier Gomez
FECHA: 13 de marzo
"""
MAX: int = 60  # Máximo tamaño del vector

# FUNCIONES DEL PRIMER PUNTO

def crear_inicializar(cual: str) -> list:
    # Inicializo el vector cual
    print("Datos del vector", cual)
    if cual == "Nombres":
        vector: list[str] = ["xxx" for pos in range(MAX)]
    else:
        vector: list[int] = [0 for pos in range(MAX)]
    return vector

def pide_tamaño() -> int:
    tam: int = -1
    while tam <= 0 or tam > MAX:
        print("Recuerde que debe ingresar un número entre 1 y", MAX)
        tam = int(input("\nIngrese el tamaño que quiere usar de los vectores: "))
    return tam

def llenar_vector(vec_nombre: list[str], vec_años: list[int], tam: int) -> None:
    print("Datos vector nombres")
    for pos in range(tam):
        nombre: str = input("\nIngrese el nombre del estudiante: ")
        vec_nombre[pos] = nombre

    print("Datos vector años")
    for pos in range(tam):
        numero: int = int(input("\nIngrese los años que llevan los padres viviendo juntos: "))
        vec_años[pos] = numero

def comparacion(vec_años: list[int], tam: int) -> int:
    cont: int = 0
    for pos in range(tam):
        if vec_años[pos] >= 25:
            cont += 1
    return cont

def comparacion2(vec_años: list[int], tam: int) -> tuple:
    pos_mas_cercano: int = 0
    pos_menos_cercano: int = 0
    diferencia_mas_cercana: int = vec_años[0] - 25
    diferencia_menos_cercana: int = vec_años[0] - 25
    
    for pos in range(tam):
        diferencia_actual: int = vec_años[pos] - 25
        if vec_años[pos] >= 25:
            continue
        if diferencia_actual < diferencia_menos_cercana:
            pos_menos_cercano = pos
            diferencia_menos_cercana = diferencia_actual
        if diferencia_actual > diferencia_mas_cercana:
            pos_mas_cercano = pos
            diferencia_mas_cercana = diferencia_actual
    
    return pos_menos_cercano, diferencia_menos_cercana, pos_mas_cercano, diferencia_mas_cercana

def mostrar_vector(vector: list, tam: int) -> None:
    print("\tDatos del vector:")
    print("\t", end="")
    print("[", end="")
    for pos in range(tam):
        print(vector[pos], end=" ")
    print("]", end="")

# FUNCIONES PARA EL SEGUNDO PUNTO

def obtener_numero_terminos() -> int:
    numero_terminos: int = -1
    while numero_terminos <= 0:
        print("Ingrese cantidad de elementos de la serie (número mayor que cero)")
        numero_terminos = int(input("\nIngrese cantidad de términos: "))
        if numero_terminos <= 0:
            print("Error: Debe ingresar un número mayor que cero.")
    return numero_terminos

def obtener_x() -> int:
    x: int = -1
    while x <= 0:
        print("Ingrese x (número mayor que cero)")
        x = int(input("\nIngrese x: "))
    return x

def factorial(numero: int) -> int:
    resultado: int = 1
    for i in range(1, numero + 1):
        resultado *= i
    return resultado

def calcular_serie_taylor_ex(x: int, numero_terminos: int) -> float:
    suma: float = 0.0
    for i in range(numero_terminos + 1):
        term: float = (x ** i) / factorial(i)
        suma += term
        print("Término", i, ":", term)
    return suma

def main() -> None:
    print("\nPrimer punto")

    # Crear e inicializar vectores
    vec_nombres: list[str] = crear_inicializar("Nombres")
    vec_años: list[int] = crear_inicializar("Años")

    # Pedir tamaño a utilizar
    tam: int = pide_tamaño()

    # Llenar el vector con los datos del usuario
    llenar_vector(vec_nombres, vec_años, tam)

    # Comparar los años para encontrar los que ya cumplieron bodas de plata
    cantidad_bodas_plata: int = comparacion(vec_años, tam)

    # Encontrar los más cercanos a cumplir y a los que les falta más
    pos_menos_cercano, diferencia_menos_cercana, pos_mas_cercano, diferencia_mas_cercana = comparacion2(vec_años, tam)

    # Mostrar resultados
    print("Los papás de", cantidad_bodas_plata, "estudiantes ya cumplieron las bodas de plata.")
    print("A los papás de", vec_nombres[pos_menos_cercano], "les falta", diferencia_menos_cercana, "años para cumplir bodas de plata.")
    print("A los papás de", vec_nombres[pos_mas_cercano], "les falta", diferencia_mas_cercana, "años para cumplir bodas de plata.")

    print("Fin del primer punto")
 
    print("\nSegundo punto")

    # Pedir cantidad de términos de la serie
    numero_terminos: int = obtener_numero_terminos()

    # Calcular la serie de Taylor para e^x
    x: int = obtener_x()
    taylor_e_x: float = calcular_serie_taylor_ex(x, numero_terminos)
    print("La aproximación de la serie de Taylor de e^x para n =", numero_terminos, "y x =", x, "es aproximadamente:", taylor_e_x)
   
    print("\nFue un placer servirle")

# Nota primer punto: 2,2 Un resultado lo arroja mal
# Nota segundo punto; 2,5
main()




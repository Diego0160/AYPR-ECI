﻿"""PROGRAMA <Parcial Segundo tercio>
================================================================
ASIGNATURA : Algoritmos y programación de computadores
OBJETIVO : Hacer un programa modular para realizar los dos puntos del parcial
AUTOR(ES) : Juan Esteban Sánchez García
FECHA: 3 de abril
"""
import time  # Para que el usuario pueda leer cómo funciona el programa

MAX = 20

print("\t### Funcionamiento del programa número 1 ###")
print("1. Se pedirá el tamaño del vector 1 y el vector 2",
      "\n2. Se pedirá la posición de inserción del vector 2 al 1",
      "\n3. Se llenan los vectores con las letras que el usuario desee",
      "\n4. Se muestran los vectores en pantalla ")
time.sleep(5)

def crear_inicializar() -> list:
    """
    Crea e inicializa un vector con un tamaño máximo, llenándolo con asteriscos.
    
    Returns:
        list: Vector inicializado con asteriscos.
    """
    vector = ["*" for pos in range(MAX)]
    return vector

def pide_tamaño() -> int:
    """
    Pide al usuario un tamaño para un vector, asegurándose de que sea válido.
    
    Returns:
        int: Tamaño ingresado por el usuario.
    """
    p = -1
    while p <= 0 or p > MAX:
        print("Recuerde que debe ingresar un número entre 1 y", MAX)
        p = int(input("\nIngrese número: "))
    return p

def llenar_vector(vector1: list, vector2: list, tam1: int, tam2: int, p: int) -> None:
    """
    Llena los vectores con caracteres ingresados por el usuario y realiza la inserción del vector2 en vector1.
    
    Args:
        vector1 (list): Primer vector.
        vector2 (list): Segundo vector.
        tam1 (int): Tamaño del primer vector.
        tam2 (int): Tamaño del segundo vector.
        p (int): Posición de inserción del segundo vector en el primero.
    """
    print("Acuerdese que solo puede ingresar letras")
    print("\t### INICIO DE ENTRADA VECTOR 1 ###")
    for pos in range(tam1):
        caracter = str(input("\nIngrese elemento del vector 1: "))
        vector1[pos] = caracter
    
    print("\t### INICIO DE ENTRADA DE DATOS VECTOR 2 ###")
    for pos in range(tam2):
        caracter = str(input("\nIngrese elemento del vector 2: "))
        vector2[pos] = caracter
        
    for pos in range(tam2 - 1, -1, -1):
        for i in range(tam1 - 1, p - 1, -1):
            vector1[i + 1] = vector1[i]
        vector1[p] = vector2[pos]
        tam1 += 1

def mostrar_resultados(vector: list, tam: int) -> None:
    """
    Muestra el contenido de un vector en pantalla.
    
    Args:
        vector (list): El vector a mostrar.
        tam (int): Tamaño del vector.
    """
    print("\t")
    print("\t", end="")
    print("[", end="")
    for pos in range(tam):
        print(vector[pos], end=" ")
    print("]", end="")

# FUNCIONES DEL SEGUNDO PUNTO
print("\t### Funcionamiento del programa número 2 ###")
print("1. Se le pide un número al usuario",
      "\n2. Por pantalla muestra el patrón solicitado ")
time.sleep(5)

def pide_numero() -> int:
    """
    Pide al usuario un número mayor o igual que cero.
    
    Returns:
        int: El número ingresado por el usuario.
    """
    num = -1
    while num < 0:
        num = int(input("Ingrese número: "))
    return num

def secuencia(num: int) -> None:
    """
    Muestra una secuencia de números según el patrón especificado.
    
    Args:
        num (int): Número hasta el cual se genera la secuencia.
    """
    for i in range(num):
        print(1, end=" ")
        for j in range(1, i+1):
            print((j*2)+(i-1)*2, end=" ")
        if i != 0:
            print(1, end="")
        print()

def main() -> None:
    """
    Función principal que controla la lógica del programa.
    """
    print("\nPrimer punto")
    vector1 = crear_inicializar()  # -> list
    vector2 = crear_inicializar()  # -> list
    print("\tIngrese tamaño del vector 1")
    tam = pide_tamaño()  # -> int
    print("\tIngrese tamaño del vector 2")
    tam2 = pide_tamaño()  # -> int
    print("\tIngrese la posición donde insertar el vector 2 en el vector 1")
    p = pide_tamaño()  # -> int
    llenar_vector(vector1, vector2, tam, tam2, p)
    print("\nEl vector 1 es: ")
    mostrar_resultados(vector1, tam)
    print("\nEl vector 2 es: ")
    mostrar_resultados(vector2, tam2)
    
    print("\nEl vector resultante al hacer la inserción del vector 2 con el vector 1 es: ")
    mostrar_resultados(vector1, tam + tam2)
    print("\nFin del primer punto")
          
    print("\nSegundo punto")
    numero = pide_numero()  # -> int
    secuencia(numero)
    print("Fin del segundo punto")

    print("\nFue un placer servirle")

# Nota: 5.0
main()  # -> None

import random

def cargar_lista():
    # Lista vacía para almacenar edades
    li = []  # 'li' es una lista
    for x in range(20):  # 'x' es un entero usado como índice en el bucle
        valor = random.randrange(18, 30)  # 'valor' es un entero
        li.append(valor)
    return li

def retornar_mayormenor(li):
    # Determinar el mayor y menor valor en la lista
    ma = li[0]  # 'ma' es un entero, inicialmente el primer elemento de la lista
    me = li[0]  # 'me' es un entero, inicialmente el primer elemento de la lista

    for x in range(1, len(li)):  # 'x' es un entero usado como índice en el bucle
        if li[x] > ma:
            ma = li[x]
        else:
            if li[x] < me:
                me = li[x]
    return ma, me  # Retorna 'ma' y 'me', ambos enteros

def mayor_y_menor(li):
    # Encontrar el mayor y menor valor en la lista usando funciones incorporadas
    mayor = max(li)  # 'mayor' es un entero
    menor = min(li)  # 'menor' es un entero
    print("El mayor es", mayor, "El menor es", menor)
    return li

def contar_edades(li):
    # Contar la frecuencia de cada edad en la lista
    conteo = []  # 'conteo' es una lista
    for k in range(18, 31):  # 'k' es un entero usado como índice en el bucle
        cantidad = li.count(k)  # 'cantidad' es un entero
        conteo.append(cantidad)
        print("Edad", k, ":", cantidad, "estudiantes")
    return conteo

def organizar_lista(li):
    # Ordenar la lista
    li.sort()
    print(li)
    return li

def eliminar_edades_repetidas(li):
    # Eliminar edades duplicadas
    li_unica = []  # 'li_unica' es una lista
    for edad in li:  # 'edad' es un entero, cada elemento de la lista
        if edad not in li_unica:
            li_unica.append(edad)
    print(li_unica)
    return li_unica

def main():
    print("\t####Bienvenido#####")
    print("Su lista inicial es")
    lista = cargar_lista()  # 'lista' es una lista
    print(lista)
    print("La cantidad de edades repetidas es: ")
    conteo = contar_edades(lista)  # 'conteo' es una lista
    mayor_y_menor(lista)
    [mayor, menor] = retornar_mayormenor(lista)  # 'mayor' y 'menor' son enteros
    print("El mayor es", mayor, "El menor es", menor)
    print("Su lista organizada es: ")
    organizar_lista(lista)
    print("Su lista sin edades repetidas es: ")
    lista2 = eliminar_edades_repetidas(lista)  # 'lista2' es una lista
    print("La longitud de la lista resultante es", len(lista2))

main()


def cargar_estudiantes():
    print("Acuerdese que en carrera ingresa: ic, ie, isis")
    estudiantes = []  # 'estudiantes' es una lista de listas
    cuantos = int(input("Ingrese la cantidad de estudiantes: "))  # 'cuantos' es un entero
    for i in range(cuantos):  # 'i' es un entero usado como índice en el bucle
        estudiante = []
        nombre = input("Nombre: ")  # 'nombre' es una cadena
        promedio = float(input("Promedio: "))  # 'promedio' es un flotante
        carrera = input("Carrera: ")  # 'carrera' es una cadena
        estudiante.append(nombre)
        estudiante.append(promedio)
        estudiante.append(carrera)
        estudiantes.append(estudiante)
    return estudiantes

def promedio(estudiantes):
    contador = 0  # 'contador' es un entero
    for j in estudiantes:  # 'j' es una lista, cada elemento de 'estudiantes'
        if j[1] >= 3:
            contador += 1
    return contador

def carreras(estudiantes):
    ic, isis, ie = 0, 0, 0  # 'ic', 'isis' y 'ie' son enteros
    for j in estudiantes:  # 'j' es una lista, cada elemento de 'estudiantes'
        carrera = j[2]  # 'carrera' es una cadena
        if carrera == "ic":
            ic += 1
        elif carrera == "isis":
            isis += 1
        elif carrera == "ie":
            ie += 1
    return [ic, isis, ie]

def mejor_promedio(estudiantes):
    mejor = 0  # 'mejor' es un flotante
    nombre = ""  # 'nombre' es una cadena
    for j in estudiantes:  # 'j' es una lista, cada elemento de 'estudiantes'
        promedio_mejor = j[1]  # 'promedio_mejor' es un flotante
        if promedio_mejor > mejor:
            mejor = promedio_mejor
            nombre = j[0]
    return [mejor, nombre]

def mostrar_resultados(estudiantes, c_prom, ic, isis, ie, mejor, nmejor):
    print("Estudiantes: ", estudiantes)
    print("Cantidad de estudiantes con promedio mayor o igual a 3: ", c_prom)
    print("Cantidad de estudiantes de IC: ", ic)
    print("Cantidad de estudiantes de IE: ", ie)
    print("Cantidad de estudiantes de ISIS: ", isis)
    print("El estudiante con el mejor promedio es ", nmejor, " con un promedio de ", mejor)

def main():
    estudiantes = cargar_estudiantes()  # 'estudiantes' es una lista de listas
    c_prom = promedio(estudiantes)  # 'c_prom' es un entero
    [ic, isis, ie] = carreras(estudiantes)  # 'ic', 'isis' y 'ie' son enteros
    [mejor, nmejor] = mejor_promedio(estudiantes)  # 'mejor' es un flotante y 'nmejor' es una cadena
    mostrar_resultados(estudiantes, c_prom, ic, isis, ie, mejor, nmejor)

main()




import random

def cargar_lista():
    # Lista vacía para almacenar sueldos
    li = []  # 'li' es una lista
    for x in range(10):  # 'x' es un entero usado como índice en el bucle
        valor = random.randrange(1000, 9999)  # 'valor' es un entero
        li.append(valor)
    return li

def sueldo_mayor(li):
    # Contar sueldos mayores a 4000
    contador = 0  # 'contador' es un entero
    for k in range(len(li)):  # 'k' es un entero usado como índice en el bucle
        if li[k] > 4000:
            contador += 1
    print("Hay", contador, "personas con un sueldo mayor a $4000")
    return contador

def promedio_sueldos(li):
    # Calcular el promedio de los sueldos
    suma = sum(li) / len(li)  # 'suma' es un flotante
    print("El promedio de los sueldos de la empresa es: ", suma)
    return suma

def bajo_promedio(li, promedio):
    # Mostrar sueldos por debajo del promedio
    print("Los sueldos por debajo del promedio son: ")
    for sueldo in li:  # 'sueldo' es un entero, cada elemento de la lista
        if sueldo < promedio:
            print(sueldo)

def main():
    print("Bienvenido")
    print("Los sueldos de las 10 personas en la empresa es de: ")
    lista = cargar_lista()  # 'lista' es una lista
    print(lista)
    promedio = promedio_sueldos(lista)  # 'promedio' es un flotante
    sueldo_mayor(lista)
    bajo_promedio(lista, promedio)

main()

   


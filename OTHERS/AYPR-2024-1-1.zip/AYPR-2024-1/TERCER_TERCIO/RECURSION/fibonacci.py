def fibonacci(x):
    # Función recursiva para calcular el término de Fibonacci
    if x == 0:
        return 0
    elif x == 1:
        return 1
    else:
        return fibonacci(x-1) + fibonacci(x-2)  # 'x' es un entero

def mostrar_serie(x):
    for i in range(x + 1):  # 'i' es un entero usado como índice en el bucle
        print(fibonacci(i), end=" ")
    print()

def main():
    x = int(input("Ingrese el número de términos para la serie de Fibonacci: "))  # 'x' es un entero
    mostrar_serie(x)

main()



    

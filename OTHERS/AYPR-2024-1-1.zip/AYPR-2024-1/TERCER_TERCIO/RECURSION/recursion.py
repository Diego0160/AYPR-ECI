def fibonacci(x):
    # Función recursiva para calcular el término de Fibonacci
    if x == 0:
        return 0
    elif x == 1:
        return 1
    else:
        return fibonacci(x-1) + fibonacci(x-2)  # 'x' es un entero

def main():
    x = int(input("Ingrese su número: "))  # 'x' es un entero
    """
    result = fibonacci(x)  # 'result' es un entero
    print(result)
    """
    for i in range(x + 1):  # 'i' es un entero usado como índice en el bucle
        print(fibonacci(i), end=" ")
    print()

main()




    

def mcd_euclides(a, b):
    # Calcular el MCD usando el algoritmo de Euclides
    if b == 0:
        return a
    else:
        cociente = a // b  # 'cociente' es un entero
        residuo = a % b  # 'residuo' es un entero
        print(a, "=", b, "*", cociente, "+", residuo)
        return mcd_euclides(b, residuo)  # 'a' y 'b' son enteros

num1 = int(input("Ingrese su primer número: "))  # 'num1' es un entero
num2 = int(input("Ingrese su segundo número: "))  # 'num2' es un entero
print("Pasos intermedios:")
mcd = mcd_euclides(num1, num2)  # 'mcd' es un entero
print("\nEl MCD de", num1, "y", num2, "es:", mcd)



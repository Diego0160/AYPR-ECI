def suma_recursiva(lista):
    # Función recursiva para sumar los elementos de una lista
    if not lista:
        return 0
    else:
        return lista[0] + suma_recursiva(lista[1:])  # 'lista' es una lista

def main():
    lista = [1, 2, 3]  # 'lista' es una lista
    print(suma_recursiva(lista))

main()



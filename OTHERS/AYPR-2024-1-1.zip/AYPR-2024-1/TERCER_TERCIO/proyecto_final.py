import os, time

# Función para mostrar el menú
def menu():
    os.system('cls')  # NOTA: para Windows debes cambiar 'clear' por 'cls'
    print("¡Hola! ¿Qué te gustaría hacer hoy?")
    print("\t1 - Agregar una nueva ruta para un avión")
    print("\t2 - Consultar la ruta de un avión específico")
    print("\t3 - Verificar si una ciudad está en la ruta de un avión")
    print("\t4 - Calcular la distancia total que recorre un avión en su ruta")
    print("\t5 - Ver el origen y el destino de todas las rutas")
    print("\t6 - Ver el origen y el destino de la ruta de un avión específico")
    print("\t7 - Ver todas las ciudades y las distancias para llegar a ellas")
    print("\t8 - Ver la distancia para llegar a una ciudad específica")
    print("\t9 - Salir del programa")

# Diccionarios de rutas y ciudades
def diccionario_rutas():
    rutas = {"AV1": "Bogotá,Lima,Arequipa", "AV2": "Medellín,Miami", "AV3": "Lima,Dubai", "AV4": "Bogotá,Roma,Tokio"}
    return rutas

def diccionario_ciudades_y_trayectos():
    trayectos = {"Bogotá": "100", "Medellín": "50", "Lima": "200", "Arequipa": "150", "Miami": "300", "Dubai": "500", "Roma": "400", "Tokio": "600"}
    return trayectos

def diccionario_destinos():
    destinos = ["Bogotá", "Lima", "Arequipa", "Medellín", "Miami", "Dubai", "Roma", "Tokio", "Cuzco", "Atenas", "Nápoles", "Pekín"]
    return destinos

# Funciones para agregar rutas
def agregar_ruta(rutas, trayectos, destinos):
    print("\tRecuerda que el código de avión debe ingresarse como AV1, AV2, AV3, AV4, etc.")
    time.sleep(2)
    while True:
        codigo_avion = input("Ingresa el código del avión: ").upper()
        if codigo_avion in rutas:
            respuesta = input("El avión ya tiene una ruta asignada. ¿Quieres añadir una nueva ruta con un nuevo código de avión? (Y/N): ")
            if respuesta.lower() != 'y':
                continue
            codigo_avion = input("Ingresa el nuevo código del avión: ").upper()
        break

    print("Selecciona las ciudades de la ruta de la siguiente lista, separadas por comas:")
    for i, destino in enumerate(destinos, start=1):
        print(f"{i}. {destino}")
    while True:
        ruta = input()
        try:
            ciudades = [destinos[int(i) - 1] for i in ruta.split(",")]  # Convierte los números a ciudades
            break
        except IndexError:
            print("Has ingresado un número de ciudad que no está en la lista. Por favor, intenta de nuevo.")

    if len(ciudades) < 2:
        print("Una ruta debe tener al menos dos ciudades. Por favor, ingresa al menos dos ciudades separadas por comas.")
        return rutas, trayectos

    # Verifica si la lista de ciudades ya existe en el diccionario de rutas
    if ', '.join(ciudades) in rutas.values():
        print("La ruta ya existe. Por favor, ingresa una ruta diferente.")
        return rutas, trayectos

    rutas[codigo_avion] = ', '.join(ciudades)  # Guarda la ruta como una cadena de texto

    for ciudad in ciudades:
        if ciudad not in trayectos:
            trayecto = input("Ingresa la distancia de trayecto para la ciudad " + ciudad + ": ")
            trayectos[ciudad] = trayecto

    print("Ruta agregada exitosamente!")
    return rutas, trayectos, destinos

def consultar_ruta(rutas):
    respuesta = input("¿Quieres ver las rutas de todos los aviones? (Y/N): ")
    if respuesta.lower() == 'y':
        for avion, ruta in rutas.items():
            print("La ruta del avión " + avion + " es: ", ruta)
    else:
        print("Selecciona el avión cuya ruta quieres consultar:")
        for i, avion in enumerate(rutas.keys(), start=1):
            print(str(i) + ". " + avion)
        indice = int(input()) - 1  # Restamos 1 porque los índices en Python empiezan en 0
        avion = list(rutas.keys())[indice]  # Convertimos las claves del diccionario a una lista para poder indexarlas
        print("La ruta del avión " + avion + " es: ", rutas[avion])

# Funciones adicionales
def calcular_distancia(rutas, trayectos, codigo_avion, indice=0):
    if codigo_avion not in rutas:
        print("El código de avión no existe.")
        return 0
    ruta = rutas[codigo_avion].split(",")  # Convertimos la ruta en una lista de ciudades
    if indice >= len(ruta):
        if indice == len(ruta):  # Solo imprimimos el resultado cuando hemos procesado todas las ciudades
            print("El avión " + codigo_avion + " con ruta " + ', '.join(ruta) + " recorre un total de " + str(sum(int(trayectos[ciudad]) for ciudad in ruta)) + " kilómetros.")
        return 0
    else:
        ciudad = ruta[indice]
        return int(trayectos[ciudad]) + calcular_distancia(rutas, trayectos, codigo_avion, indice + 1)

def ciudad_en_ruta(rutas, codigo_avion, ciudad):
    if codigo_avion not in rutas:
        print("El código de avión no existe.")
        return
    ruta = rutas[codigo_avion]
    if ciudad in ruta:
        print("La ciudad " + ciudad + " hace parte de la ruta del avión " + codigo_avion + ".")
    else:
        print("La ciudad " + ciudad + " no hace parte de la ruta del avión " + codigo_avion + ".")

def imprimir_rutas(rutas):
    for avion, ruta in rutas.items():
        print("Avión: " + avion + ", Ruta: " + ', '.join(ruta))

def imprimir_origen_destino(rutas):
    for avion, ruta in rutas.items():
        ciudades = ruta.split(",")  # Convertimos la ruta en una lista de ciudades
        print("Avión: " + avion + ", Origen: " + ciudades[0] + ", Destino: " + ciudades[-1])

def imprimir_origen_destino_avion(rutas, codigo_avion):
    if codigo_avion not in rutas:
        print("El código de avión no existe.")
        return
    ciudades = rutas[codigo_avion].split(",")  # Convertimos la ruta en una lista de ciudades
    print("Avión: " + codigo_avion + ", Origen: " + ciudades[0] + ", Destino: " + ciudades[-1])

def imprimir_distancia_ciudad(trayectos, ciudad):
    if ciudad not in trayectos:
        print("La ciudad no existe.")
        return
    distancia = trayectos[ciudad]
    print("La distancia para llegar a la ciudad " + ciudad + " es de " + distancia + " kilómetros.")

def imprimir_ciudades_trayectos(trayectos):
    for ciudad, distancia in trayectos.items():
        print("Ciudad: " + ciudad + ", Distancia: " + distancia + " kilómetros")

def procesando_solicitud():
    print("Un momento por favor, procesando solicitud", end="")
    for i in range(3):  # Número de veces que quieres que los puntos titilen
        print(".", end="", flush=True)
        time.sleep(1)  # Tiempo que quieres que los puntos titilen
    print("\n")

# Diccionarios de rutas, ciudades y destinos
rutas = diccionario_rutas()
trayectos = diccionario_ciudades_y_trayectos()
destinos = diccionario_destinos()

def main():
    print("Bienvenidos al programa de Gestión de Rutas de Aviones")

    while True:
        menu()

        opcionMenu = input("Inserta uno de los números que se muestran en pantalla >> ")

        if opcionMenu == "1":
            procesando_solicitud()
            agregar_ruta(rutas, trayectos, destinos)
            print(rutas)
            print(trayectos)
            input("Has pulsado la opción 1...\npulsa una tecla para continuar")

        elif opcionMenu == "2":
            procesando_solicitud()
            consultar_ruta(rutas)
            input("Has pulsado la opción 2...\npulsa una tecla para continuar")

        elif opcionMenu == "3":
            procesando_solicitud()
            codigo_avion = input("Ingresa el código del avión: ").upper()
            ciudad = input("Ingresa la ciudad: ")
            ciudad_en_ruta(rutas, codigo_avion, ciudad)
            input("Has pulsado la opción 3...\npulsa una tecla para continuar")

        elif opcionMenu == "4":
            procesando_solicitud()
            codigo_avion = input("Ingresa el código del avión: ").upper()
            calcular_distancia(rutas, trayectos, codigo_avion)
            input("Has pulsado la opción 4...\npulsa una tecla para continuar")

        elif opcionMenu == "5":
            procesando_solicitud()
            imprimir_origen_destino(rutas)
            input("Has pulsado la opción 5...\npulsa una tecla para continuar")

        elif opcionMenu == "6":
            procesando_solicitud()
            codigo_avion = input("Ingresa el código del avión: ").upper()
            imprimir_origen_destino_avion(rutas, codigo_avion)
            input("Has pulsado la opción 6...\npulsa una tecla para continuar")

        elif opcionMenu == "7":
            procesando_solicitud()
            imprimir_ciudades_trayectos(trayectos)
            input("Has pulsado la opción 7...\npulsa una tecla para continuar")

        elif opcionMenu == "8":
            procesando_solicitud()
            ciudad = input("Ingresa la ciudad: ")
            imprimir_distancia_ciudad(trayectos, ciudad)
            input("Has pulsado la opción 8...\npulsa una tecla para continuar")

        elif opcionMenu == "9":
            print("Chao Chao")
            break

        else:
            print("")
            input("No has pulsado ninguna opción correcta...\npulsa una tecla para continuar")

main()



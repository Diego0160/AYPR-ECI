def cargar():
    # Diccionario para almacenar información completa de los estudiantes
    alumnos = {}  # 'alumnos' es un diccionario
    cuantos = int(input("Querido usuario digite cuantos elementos quiere en su diccionario: "))  # 'cuantos' es un entero
    for i in range(cuantos):  # 'i' es un entero usado como índice en el bucle
        clave = input("Escriba codigo de estudiante: ")  # 'clave' es una cadena
        valor = []
        nombre = input("Digite el nombre del estudiante: ")  # 'nombre' es una cadena
        apellido = input("Digite el apellido del estudiante")  # 'apellido' es una cadena
        edad = int(input("¿Cuantos años tiene el estudiante?: "))  # 'edad' es un entero
        fecha = input("Digite la fecha de nacimiento: ")  # 'fecha' es una cadena
        valor.append(nombre)
        valor.append(apellido)
        valor.append(edad)
        valor.append(fecha)
        alumnos[clave] = valor
    return alumnos

def listar(alumnos):
    print("El diccionario es", alumnos)
    for clave in alumnos:  # 'clave' es una cadena, llave del diccionario
        print("Clave", clave, "Valor es una lista", alumnos[clave])
    for elem in alumnos[clave]:  # 'elem' es una cadena, cada elemento de la lista 'alumnos[clave]'
        print("datos estudiante", elem)

def listar2(alumnos):
    for clave in alumnos:  # 'clave' es una cadena, llave del diccionario
        print("Codigo del alumno", clave)
        print("Nombre: ", alumnos[clave][0])
        print("Apellido: ", alumnos[clave][1])
        print("Edad: ", alumnos[clave][2])
        print("Fecha de nacimiento: ", alumnos[clave][3])

def mayores20(alumnos):
    for clave in alumnos:  # 'clave' es una cadena, llave del diccionario
        if alumnos[clave][2] > 20:  # 'edad' es un entero, tercer elemento de la lista 'alumnos[clave]'
            print("Nombre: ", alumnos[clave][0])
            print("Apellido: ", alumnos[clave][1])
            print("Codigo del alumno", clave)
            print("Edad: ", alumnos[clave][2])
            print("Fecha de nacimiento: ", alumnos[clave][3])
            print("\n")

def main():
    alumnos = cargar()  # 'alumnos' es un diccionario
    print("Imprime tal cual el diccionario")
    print(alumnos)
    print("Listar de una forma\n")
    listar(alumnos)
    print("Listar de otra forma\n")
    listar2(alumnos)
    print("Mayores de 20\n")
    mayores20(alumnos)

main()


def cargar_articulos():
    # Diccionario para almacenar artículos y sus valores
    articulos = {}  # 'articulos' es un diccionario
    for i in range(3):  # 'i' es un entero usado como índice en el bucle
        clave = str(input("Ingrese la clave: "))  # 'clave' es una cadena
        valor = int(input("Ingrese el valor: "))  # 'valor' es un entero
        articulos[clave] = valor
    return articulos

def imprimir_articulos(articulos):
    # Iterar sobre el diccionario y imprimir los valores
    for clave in articulos:  # 'clave' es una cadena, llave del diccionario
        print("Nombre articulo: ", clave)
        print("Valor del articulo: ", articulos[clave])

def imprimir_mayores1000(articulos):
    # Imprimir artículos con valor mayor a 1000
    for clave in articulos:  # 'clave' es una cadena, llave del diccionario
        if articulos[clave] > 1000:
            print("Nombre articulo: ", clave)
            print("Valor del articulo: ", articulos[clave])

def main():
    articulos = cargar_articulos()  # 'articulos' es un diccionario
    imprimir_articulos(articulos)
    imprimir_mayores1000(articulos)

main()

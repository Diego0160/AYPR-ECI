def cargar_estudiantes():
    # Diccionario para almacenar estudiantes y sus promedios
    estudiantes = {}  # 'estudiantes' es un diccionario
    cuantos = int(input("Querido usuario digite cuantos elementos quiere en su diccionario: "))  # 'cuantos' es un entero
    for i in range(cuantos):  # 'i' es un entero usado como índice en el bucle
        clave = str(input("Ingrese el nombre del estudiante: "))  # 'clave' es una cadena
        valor = float(input("Ingrese el promedio del estudiante: "))  # 'valor' es un flotante
        estudiantes[clave] = valor
    return estudiantes

def imprimir_estudiantes(estudiantes):
    # Iterar sobre el diccionario y imprimir los valores
    for clave in estudiantes:  # 'clave' es una cadena, llave del diccionario
        print("Nombre de estudiante: ", clave)
        print("Promedio: ", estudiantes[clave])

def main():
    estudiantes = cargar_estudiantes()  # 'estudiantes' es un diccionario
    imprimir_estudiantes(estudiantes)

main()


